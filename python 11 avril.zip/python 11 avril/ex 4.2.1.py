x = int(input("x :"))
y = int(input("y :"))
z = int(input("z :"))

if x == y == z:
        print("True")
else:
        print("False")
