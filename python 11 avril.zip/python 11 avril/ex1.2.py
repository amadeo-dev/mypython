n = int(input("Ton nombre :"))
for b in range(0,n+1)  :
        print(b, "x", n, "=", b * n)

