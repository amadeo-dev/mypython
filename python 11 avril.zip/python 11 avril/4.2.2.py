x = int(input("x :"))
y = int(input("y :"))
z = int(input("z :"))

if x == z or x == y or y == z:
        print("True")
else:
        print("False")