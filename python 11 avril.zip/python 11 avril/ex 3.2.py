a = int(input("A :> "))
b = int(input("B :> "))

if a > b:
        print("Erreur")
else:
    y = int(input("y : "))
if y > a and y < b:
            print("y est dans l'intervalle[AB]")
else:
            print("y n'est pas dans l'intervalle[AB]")
