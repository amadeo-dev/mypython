n = int((input("Ton nombre:> ")))
if n / 2 == 0:
        print("impair")
else:
        print("pair")
