x = int(input("x :"))
y = int(input("y :"))
z = int(input("z :"))

if x == y and x =! z and y =! z:
        print("True")
elif x == z and x =! y and z =! y:
        print("True")
elif y == z and y =! x and z =! x:
        print("True")
else:
        print("False")