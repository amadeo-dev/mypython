n = int(input("Saisir le nombre a tester :> "))

if n % 2 == 0:
        print("Pair")
else:
        print("Impair")
